GVA calculation logs
====================
results/logs/                 v2 molecular runs and all v3 periodic runs
  run_small.log, run_cisplatin.log, run_pes.log, run_orbital_sensitivity.log
  run_periodic_A.log ... run_periodic_G.log   periodic benchmark, seven parts
      (A, B, D stopped at the 2-h job limit; E stopped by hand during ADAPT-VQE;
       every completed run is in results/periodic.json; see PROVENANCE.md, section 9)
  run_scaling_periodic.log, run_measure_periodic.log
  tests_periodic.log, verify_periodic.log, verify_periodic.stdout,
  analyze_tying_periodic.log, check_jw_cisplatin.log, verify_theta.log,
  compare_v1_v2.txt, periodic_start_time.txt, v2_start_time.txt
  pyscf/       full PySCF output (verbose 4): molecular runs and the CISD/CCSD/
               CCSD(T)/FCI references of every periodic system (<system>__mol1.log)
  pyscf_pbc/   PySCF output of the periodic KRHF (<system>__krhf.log) and of the
               independent explicit-supercell check (<system>__supercell.log)
results_v1/logs/              original (v1) run logs, validation and reference logs
